exports.handler = async (event, context) => {
    console.log("HELLO FROM DUMMY LAMBDA");
}
